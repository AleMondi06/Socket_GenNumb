﻿namespace Client
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.GeneraNumeroButton = new System.Windows.Forms.Button();
            this.NumeroLabel = new System.Windows.Forms.Label();
            this.Exit_Client = new System.Windows.Forms.Button();
            this.Open_Client = new System.Windows.Forms.Button();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // GeneraNumeroButton
            // 
            this.GeneraNumeroButton.Location = new System.Drawing.Point(218, 177);
            this.GeneraNumeroButton.Name = "GeneraNumeroButton";
            this.GeneraNumeroButton.Size = new System.Drawing.Size(100, 78);
            this.GeneraNumeroButton.TabIndex = 0;
            this.GeneraNumeroButton.Text = "Genera Numero";
            this.GeneraNumeroButton.UseVisualStyleBackColor = true;
            this.GeneraNumeroButton.Click += new System.EventHandler(this.GeneraNumeroButton_Click);
            // 
            // NumeroLabel
            // 
            this.NumeroLabel.AutoSize = true;
            this.NumeroLabel.Location = new System.Drawing.Point(358, 210);
            this.NumeroLabel.Name = "NumeroLabel";
            this.NumeroLabel.Size = new System.Drawing.Size(42, 13);
            this.NumeroLabel.TabIndex = 1;
            this.NumeroLabel.Text = "numero";
            // 
            // Exit_Client
            // 
            this.Exit_Client.Location = new System.Drawing.Point(218, 261);
            this.Exit_Client.Name = "Exit_Client";
            this.Exit_Client.Size = new System.Drawing.Size(100, 78);
            this.Exit_Client.TabIndex = 2;
            this.Exit_Client.Text = "Esci dal Client";
            this.Exit_Client.UseVisualStyleBackColor = true;
            this.Exit_Client.Click += new System.EventHandler(this.Exit_Client_Click);
            // 
            // Open_Client
            // 
            this.Open_Client.Location = new System.Drawing.Point(218, 93);
            this.Open_Client.Name = "Open_Client";
            this.Open_Client.Size = new System.Drawing.Size(100, 78);
            this.Open_Client.TabIndex = 3;
            this.Open_Client.Text = "Apri il Client";
            this.Open_Client.UseVisualStyleBackColor = true;
            this.Open_Client.Click += new System.EventHandler(this.Open_Client_Click);
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Location = new System.Drawing.Point(348, 123);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(117, 20);
            this.PasswordTextBox.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(345, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Inserisci la password";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PasswordTextBox);
            this.Controls.Add(this.Open_Client);
            this.Controls.Add(this.Exit_Client);
            this.Controls.Add(this.NumeroLabel);
            this.Controls.Add(this.GeneraNumeroButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button GeneraNumeroButton;
        private System.Windows.Forms.Label NumeroLabel;
        private System.Windows.Forms.Button Exit_Client;
        private System.Windows.Forms.Button Open_Client;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.Label label1;
    }
}

